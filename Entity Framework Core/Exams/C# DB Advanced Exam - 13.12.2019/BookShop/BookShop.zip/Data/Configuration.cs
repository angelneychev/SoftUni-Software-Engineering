﻿namespace BookShop.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=ANGEL_LAPTOP\SQLEXPRESS;Database=BookShop;Trusted_Connection=True";
    }
}