﻿namespace WildFarm.Models.Foods.Entities
{
    public class Meat : Food
    {
        public Meat(int quantity) 
            : base(quantity)
        {
        }
    }
}
