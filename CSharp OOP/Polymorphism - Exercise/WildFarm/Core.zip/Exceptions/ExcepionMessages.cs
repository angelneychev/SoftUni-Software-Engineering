﻿namespace WildFarm.Exceptions
{
    public static class ExcepionMessages
    {
        public static string InvalidFoodTypeException = "{0} does not eat {1}!";
    }
}
