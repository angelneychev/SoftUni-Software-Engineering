﻿namespace AnimalCentre.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
