﻿namespace AnimalCentre.Models.Contracts
{
    public interface IAnimal
    {
       //Implement me
       string Name { get; }
       int Happiness { get; set; }
       int Energy { get; set; }
       int ProcedureTime { get; set; }
       string Owner { get; set; } //Owner – string (by default: "Centre")
       bool IsAdopt { get; set; } //IsAdopt – bool (by default: false)
       bool IsChipped { get; set; } //IsChipped – bool (by default: false)
       bool IsVaccinated { get; set; } //IsVaccinated – bool (by default: false)
    }
}
