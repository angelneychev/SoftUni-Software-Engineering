﻿namespace WildFarm.Models.Foods.Entities
{
    public class Fruit : Food
    {
        public Fruit(int quantity) 
            : base(quantity)
        {
        }
    }
}
