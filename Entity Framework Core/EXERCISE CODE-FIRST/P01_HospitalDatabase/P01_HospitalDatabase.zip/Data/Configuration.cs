﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_HospitalDatabase.Data
{
    static class Configuration
    {
        internal static string ConnetionString =
            @"Server=ANGEL_LAPTOP\SQLEXPRESS;Database=HospitalDatabase;Integrated Security=True";
    }
}
