﻿namespace WildFarm.Models.Foods.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    public interface IFood
    {
        int Quantity { get; }
    }
}
