﻿using P01_StudentSystem.Data;
using P01_StudentSystem.Data.EntityConfiguration;

namespace P01_StudentSystem
{
    using System;
    public class StartUp
    {
        public static void Main(string[] args)
        {
            //using (StudentSystemContext context = new StudentSystemContext())
            //{
            //    context.Database.EnsureDeleted();
            //    context.Database.EnsureCreated();
            //}
        }
    }
}
