﻿namespace VaporStore.Data.Models.Enum
{
	public enum CardType
	{
		Debit,
		Credit
	}
}