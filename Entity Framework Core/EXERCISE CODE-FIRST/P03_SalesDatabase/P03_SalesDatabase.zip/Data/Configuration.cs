﻿namespace P03_SalesDatabase.Data
{
    static class Configuration
    {
        internal static string ConnetionString =
            @"Server=ANGEL_LAPTOP\SQLEXPRESS;Database=SalseDatebase;Integrated Security=True";
    }
}
