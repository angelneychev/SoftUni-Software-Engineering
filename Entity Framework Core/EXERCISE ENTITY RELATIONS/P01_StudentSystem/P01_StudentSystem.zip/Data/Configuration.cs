﻿namespace P01_StudentSystem.Data
{
    public class Configuration
    {
        public const string ConfigurationString =
            @"Server=ANGEL_LAPTOP\SQLEXPRESS;Database=StudentSystem;Integrated Security=True";
    }
}
